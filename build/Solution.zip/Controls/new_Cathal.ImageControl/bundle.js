var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./ImageControl/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./ImageControl/index.ts":
/*!*******************************!*\
  !*** ./ImageControl/index.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar ImageControl =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function ImageControl() {\n    this.CSSClasses = {\n      Hidden: \"hidden\",\n      ImageControlContainer: \"imageControl-container\",\n      ClearButton: \"clearButton\",\n      ClearButtonContainer: \"clearButton-container\",\n      ImageBorder: \"image-border\"\n    };\n    this.Constants = {\n      MultipleLineMaxFieldLength: 1048576,\n      Val: \"val\",\n      Yes: \"yes\"\n    };\n    this.ResourceStrings = {\n      DragImageHere: \"DragImageHere_message\",\n      NoFileError_message: \"NoFileError_message\",\n      DragImageHere_message: \"DragImageHere_message\",\n      ClickToClear_message: \"ClickToClear_message\",\n      MultipleFileError_message: \"MultipleFileError_message\",\n      FileTypeError_message: \"FileTypeError_message\",\n      FieldMetadataMissingError_message: \"FieldMetadataMissingError_message\",\n      FieldLengthError_message: \"FieldLengthError_message\",\n      MaxFieldLengthError_message: \"MaxFieldLengthError_message\"\n    }; // Bind functions\n\n    this.addEventListeners = this.addEventListeners.bind(this);\n    this.createElements = this.createElements.bind(this);\n    this.removeEventListeners = this.removeEventListeners.bind(this);\n    this.toBase64 = this.toBase64.bind(this);\n    this.addDataImage = this.addDataImage.bind(this);\n    this.removeDataImage = this.removeDataImage.bind(this);\n    this.alertError = this.alertError.bind(this);\n    this.onDragOver = this.onDragOver.bind(this);\n    this.onDrop = this.onDrop.bind(this);\n    this.onDropSuccess = this.onDropSuccess.bind(this);\n    this.validateFieldLength = this.validateFieldLength.bind(this);\n    this.clearButtonClick = this.clearButtonClick.bind(this);\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  ImageControl.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this.context = context;\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.container = container;\n    this.fieldMetadata = this.context.parameters.field.attributes;\n    this.createElements();\n    this.addEventListeners();\n    this.updateView(context);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  ImageControl.prototype.updateView = function (context) {\n    this.context = context;\n    var error = false;\n\n    if (!context.parameters || !context.parameters.field || !context.parameters.field.raw || context.parameters.field.raw === this.Constants.Val) {\n      error = true;\n    }\n\n    var hidden = this.CSSClasses.Hidden;\n\n    if (error) {\n      // Show the label\n      if (this.label.classList.contains(hidden)) {\n        this.label.classList.remove(hidden);\n      } // Hide the image and button\n\n\n      this.img.src = \"\";\n\n      if (!this.img.classList.contains(hidden)) {\n        this.img.classList.add(hidden);\n      }\n\n      if (!this.clearButton.classList.contains(hidden)) {\n        this.clearButton.classList.add(hidden);\n      }\n    } else {\n      // Hide the label\n      if (!this.label.classList.contains(hidden)) {\n        this.label.classList.add(hidden);\n      } // Show the image and button\n\n\n      this.img.src = this.addDataImage(context.parameters.field.raw);\n\n      if (this.img.classList.contains(hidden)) {\n        this.img.classList.remove(hidden);\n      }\n\n      if (this.clearButton.classList.contains(hidden)) {\n        this.clearButton.classList.remove(hidden);\n      }\n    } // Image border\n\n\n    if (this.context.parameters.imageBorder.raw === this.Constants.Yes && !this.img.classList.contains(this.CSSClasses.ImageBorder)) {\n      this.img.classList.add(this.CSSClasses.ImageBorder);\n    } else if (this.context.parameters.imageBorder.raw !== this.Constants.Yes && this.img.classList.contains(this.CSSClasses.ImageBorder)) {\n      this.img.classList.remove(this.CSSClasses.ImageBorder);\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  ImageControl.prototype.getOutputs = function () {\n    return {\n      field: this.context.parameters.field.raw,\n      length: this.context.parameters.field.raw.length\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  ImageControl.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n    this.removeEventListeners();\n  };\n\n  ImageControl.prototype.createElements = function () {\n    var resources = this.context.resources;\n    var hidden = this.CSSClasses.Hidden;\n    var imageControlContainer = document.createElement(\"div\");\n    imageControlContainer.classList.add(this.CSSClasses.ImageControlContainer);\n    this.container.appendChild(imageControlContainer);\n    this.img = document.createElement(\"img\");\n    this.img.classList.add(hidden);\n\n    if (this.context.parameters.imageBorder.raw === this.Constants.Yes) {\n      this.img.classList.add(this.CSSClasses.ImageBorder);\n    }\n\n    imageControlContainer.appendChild(this.img);\n    this.label = document.createElement(\"label\");\n    this.label.classList.add(hidden);\n    this.label.innerText = resources.getString(this.ResourceStrings.DragImageHere_message);\n    imageControlContainer.appendChild(this.label);\n    var clearButtonContainer = document.createElement(\"div\");\n    clearButtonContainer.classList.add(this.CSSClasses.ClearButtonContainer);\n    imageControlContainer.appendChild(clearButtonContainer);\n    this.clearButton = document.createElement(\"button\");\n    this.clearButton.classList.add(hidden);\n    this.clearButton.classList.add(this.CSSClasses.ClearButton);\n    this.clearButton.innerText = resources.getString(this.ResourceStrings.ClickToClear_message);\n    clearButtonContainer.appendChild(this.clearButton);\n  };\n\n  ImageControl.prototype.alertError = function (message, details) {\n    var options = {\n      message: message\n    };\n\n    if (details) {\n      if (details.trim() !== '') {\n        options.details = details;\n      }\n    }\n\n    this.context.navigation.openErrorDialog(options);\n    return message;\n  };\n\n  ImageControl.prototype.onDragOver = function (ev) {\n    ev.preventDefault();\n  };\n\n  ImageControl.prototype.onDrop = function (ev) {\n    ev.preventDefault();\n\n    if (!ev.dataTransfer) {\n      return;\n    }\n\n    if (!ev.dataTransfer.files) {\n      return;\n    }\n\n    var resources = this.context.resources;\n    var files = ev.dataTransfer.files;\n\n    if (files.length === 0) {\n      this.alertError(resources.getString(this.ResourceStrings.NoFileError_message));\n      return;\n    }\n\n    if (files.length > 1) {\n      this.alertError(resources.getString(this.ResourceStrings.MultipleFileError_message));\n      return;\n    }\n\n    var file = files[0];\n\n    if (file.type !== \"image/png\") {\n      this.alertError(resources.getString(this.ResourceStrings.FileTypeError_message));\n      return;\n    }\n\n    this.toBase64(file).then(this.validateFieldLength, this.alertError).then(this.onDropSuccess, this.alertError);\n  };\n\n  ImageControl.prototype.onDropSuccess = function (message) {\n    this.context.parameters.field.raw = this.removeDataImage(message);\n    this.updateView(this.context);\n    this.notifyOutputChanged();\n  };\n\n  ImageControl.prototype.addEventListeners = function () {\n    this.container.ondragover = this.onDragOver;\n    this.container.ondrop = this.onDrop;\n    this.clearButton.onclick = this.clearButtonClick;\n  };\n\n  ImageControl.prototype.removeEventListeners = function () {\n    this.container.ondragover = null;\n    this.container.ondrop = null;\n    this.clearButton.onclick = null;\n  };\n\n  ImageControl.prototype.toBase64 = function (file) {\n    return new Promise(function (resolve, reject) {\n      var reader = new FileReader();\n      reader.readAsDataURL(file);\n\n      reader.onload = function () {\n        return resolve(reader.result);\n      };\n\n      reader.onerror = function (error) {\n        return reject(error);\n      };\n    });\n  };\n\n  ImageControl.prototype.addDataImage = function (base64String) {\n    return \"data:image/png;base64,\" + base64String;\n  };\n\n  ImageControl.prototype.removeDataImage = function (base64String) {\n    return base64String.replace(\"data:image/png;base64,\", \"\");\n  };\n\n  ImageControl.prototype.validateFieldLength = function (text) {\n    var _this = this;\n\n    return new Promise(function (resolve, reject) {\n      var resources = _this.context.resources;\n\n      if (!_this.fieldMetadata) {\n        reject(resources.getString(_this.ResourceStrings.FieldMetadataMissingError_message));\n      } else if (text.length > _this.Constants.MultipleLineMaxFieldLength) {\n        reject(resources.getString(_this.ResourceStrings.MaxFieldLengthError_message));\n      } else if (text.length > _this.fieldMetadata.MaxLength) {\n        reject(resources.getString(_this.ResourceStrings.FieldLengthError_message));\n      } else {\n        resolve(text);\n      }\n    });\n  };\n\n  ImageControl.prototype.clearButtonClick = function (ev) {\n    this.context.parameters.field.raw = \"\";\n    this.updateView(this.context);\n    this.notifyOutputChanged();\n  };\n\n  return ImageControl;\n}();\n\nexports.ImageControl = ImageControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ImageControl/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Cathal.ImageControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ImageControl);
} else {
	var Cathal = Cathal || {};
	Cathal.ImageControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ImageControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}